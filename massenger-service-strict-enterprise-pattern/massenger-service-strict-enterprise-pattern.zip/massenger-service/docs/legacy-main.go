//go:build legacy
// +build legacy

package main

import (
	"context"
	"dift_backend_go/messaging-service/internal/servicecore"
	"encoding/json"
	"fmt"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"

	"dift_backend_go/messaging-service/config"
	"dift_backend_go/messaging-service/internal/db"
	"dift_backend_go/messaging-service/internal/handler"
	eventnats "dift_backend_go/messaging-service/internal/integration/event"
	"dift_backend_go/messaging-service/internal/logger"
	"dift_backend_go/messaging-service/internal/service"

	"github.com/redis/go-redis/v9"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
)

func main() {
	_ = sc.NewEngineUnifiedBundle(sc.LoadEngineUnifiedConfigFromEnv("massenger-service"))
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	cfg, err := config.LoadConfig(".")
	if err != nil {
		panic(err)
	}

	appLogger := logger.NewLogger(cfg.LogLevel)
	appLogger.Info("starting messaging-service")

	natsConn, err := eventnats.Connect(cfg.NATS.URL)
	if err != nil {
		appLogger.Error("failed connect NATS", slog.Any("error", err))
		os.Exit(1)
	}
	defer natsConn.Close()

	mongoClient, err := mongo.Connect(ctx, options.Client().ApplyURI(cfg.Mongo.URI))
	if err != nil {
		appLogger.Error("failed connect MongoDB", slog.Any("error", err))
		os.Exit(1)
	}
	defer func() {
		_ = mongoClient.Disconnect(context.Background())
	}()

	repo, err := db.NewMongoRepository(ctx, mongoClient, cfg.Mongo.Database, cfg.Mongo.Collection, appLogger)
	if err != nil {
		appLogger.Error("failed init repository", slog.Any("error", err))
		os.Exit(1)
	}

	redisClient := redis.NewClient(&redis.Options{
		Addr:     cfg.Redis.URL,
		Password: cfg.Redis.Password,
		DB:       cfg.Redis.DB,
	})
	if err := redisClient.Ping(ctx).Err(); err != nil {
		appLogger.Error("failed connect redis", slog.Any("error", err))
		os.Exit(1)
	}
	defer func() {
		_ = redisClient.Close()
	}()

	svc := service.NewMessagingService(appLogger, natsConn, repo, redisClient, cfg.NATS.DeliveryPrefix)
	serviceID := fmt.Sprintf("%s-%d", hostnameOrDefault(), os.Getpid())
	hub := handler.NewHub(appLogger, svc, natsConn, serviceID, cfg.NATS.DeliveryPrefix)

	mux := http.NewServeMux()
	mux.HandleFunc("/ws", hub.ServeWS)
	mux.HandleFunc("/healthz", func(w http.ResponseWriter, _ *http.Request) {
		w.WriteHeader(http.StatusOK)
		_, _ = w.Write([]byte("ok"))
	})
	mux.HandleFunc("/internal/admin/control", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			w.WriteHeader(http.StatusMethodNotAllowed)
			return
		}
		secret := strings.TrimSpace(os.Getenv("ADMIN_CONTROL_SHARED_SECRET"))
		if secret != "" && r.Header.Get("X-Admin-Secret") != secret {
			w.WriteHeader(http.StatusUnauthorized)
			_ = json.NewEncoder(w).Encode(map[string]any{"error": "unauthorized"})
			return
		}
		var req map[string]any
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			w.WriteHeader(http.StatusBadRequest)
			_ = json.NewEncoder(w).Encode(map[string]any{"error": "invalid_json"})
			return
		}
		action, _ := req["action"].(string)
		if strings.TrimSpace(action) == "" {
			w.WriteHeader(http.StatusBadRequest)
			_ = json.NewEncoder(w).Encode(map[string]any{"error": "action_required"})
			return
		}
		w.WriteHeader(http.StatusAccepted)
		_ = json.NewEncoder(w).Encode(map[string]any{"accepted": true, "service": "massenger-service", "action": action})
	})

	httpSrv := &http.Server{
		Addr:              fmt.Sprintf(":%d", cfg.Server.WebSocketPort),
		Handler:           mux,
		ReadHeaderTimeout: 10 * time.Second,
		IdleTimeout:       60 * time.Second,
	}

	go func() {
		appLogger.Info("websocket server started", slog.String("addr", httpSrv.Addr), slog.String("service_id", serviceID))
		if err := httpSrv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			appLogger.Error("http server failed", slog.Any("error", err))
			cancel()
		}
	}()

	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT, syscall.SIGTERM)
	select {
	case sig := <-sigChan:
		appLogger.Info("shutdown signal received", slog.String("signal", sig.String()))
	case <-ctx.Done():
		appLogger.Info("shutdown requested from context")
	}

	shutdownCtx, shutdownCancel := context.WithTimeout(context.Background(), 15*time.Second)
	defer shutdownCancel()
	if err := httpSrv.Shutdown(shutdownCtx); err != nil {
		appLogger.Error("http shutdown failed", slog.Any("error", err))
	}
	if err := natsConn.Drain(); err != nil {
		appLogger.Warn("nats drain failed", slog.Any("error", err))
	}
}

func hostnameOrDefault() string {
	h, err := os.Hostname()
	if err != nil || h == "" {
		return "messaging"
	}
	return h
}
