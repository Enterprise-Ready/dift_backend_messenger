package service

import (
	"context"
	"fmt"
	"log/slog"
	"time"

	"dift_backend_go/messaging-service/internal/db"
	"dift_backend_go/messaging-service/internal/pb"

	"github.com/google/uuid"
	"github.com/nats-io/nats.go"
	"github.com/redis/go-redis/v9"
	"google.golang.org/protobuf/proto"
	"google.golang.org/protobuf/types/known/timestamppb"
)

const (
	userLocationKeyPrefix = "user_location:"
	userLocationExpiry    = 5 * time.Minute // Extend this on activity
)

type MessagingService struct {
	logger         *slog.Logger
	natsConn       *nats.Conn
	repo           db.MessengerRepository
	redisClient    *redis.Client
	deliveryPrefix string // e.g., "messages.delivery"
}

func NewMessagingService(logger *slog.Logger, nc *nats.Conn, repo db.MessengerRepository, rc *redis.Client, deliveryPrefix string) *MessagingService {
	return &MessagingService{
		logger:         logger,
		natsConn:       nc,
		repo:           repo,
		redisClient:    rc,
		deliveryPrefix: deliveryPrefix,
	}
}

// SendMessage handles persisting and routing a message.
func (s *MessagingService) SendMessage(ctx context.Context, msg *pb.Message) error {
	// 1. Enrich the message
	msg.Id = uuid.NewString()
	msg.Timestamp = timestamppb.Now()

	// 2. Persist the message *first*
	if err := s.repo.SaveMessage(ctx, msg); err != nil {
		s.logger.Error("Failed to save message to DB", slog.Any("error", err), slog.String("from", msg.From), slog.String("to", msg.To))
		return err // Fail fast; don't try to deliver if we can't save.
	}
	s.logger.Info("Message saved to DB", slog.String("msg_id", msg.Id))

	// 3. Find recipient's location from Redis
	recipientLocationKey := userLocationKeyPrefix + msg.To
	serviceID, err := s.redisClient.Get(ctx, recipientLocationKey).Result()

	if err == redis.Nil {
		// User is offline. Message is already saved. We're done.
		s.logger.Info("Recipient is offline, message saved.", slog.String("recipient_id", msg.To))
		return nil
	}
	if err != nil {
		s.logger.Error("Failed to get recipient location from Redis", slog.Any("error", err), slog.String("recipient_id", msg.To))
		// We still return nil because the message *was* saved.
		// Delivery is best-effort.
		return nil
	}

	// 4. Recipient is online. Route message via NATS to the specific service.
	data, err := proto.Marshal(msg)
	if err != nil {
		s.logger.Error("Failed to marshal message for NATS", slog.Any("error", err), slog.String("msg_id", msg.Id))
		return nil // Saved, but can't deliver.
	}

	deliveryTopic := fmt.Sprintf("%s.%s", s.deliveryPrefix, serviceID)
	if err := s.natsConn.Publish(deliveryTopic, data); err != nil {
		s.logger.Error("Failed to publish message to NATS", slog.Any("error", err), slog.String("topic", deliveryTopic))
		return nil // Saved, but can't deliver.
	}

	s.logger.Info("Message routed via NATS", slog.String("msg_id", msg.Id), slog.String("topic", deliveryTopic))
	return nil
}

// GetMessageHistory retrieves recent messages for a conversation.
func (s *MessagingService) GetMessageHistory(ctx context.Context, conversationID string, limit int) ([]*pb.Message, error) {
	return s.repo.GetMessages(ctx, conversationID, limit)
}

// RegisterUserLocation registers a user's connected service ID in Redis.
func (s *MessagingService) RegisterUserLocation(ctx context.Context, userID, serviceID string) error {
	key := userLocationKeyPrefix + userID
	if err := s.redisClient.Set(ctx, key, serviceID, userLocationExpiry).Err(); err != nil {
		s.logger.Error("Failed to register user location in Redis", slog.Any("error", err), slog.String("user_id", userID))
		return err
	}
	return nil
}

// UnregisterUserLocation removes a user's location from Redis.
func (s *MessagingService) UnregisterUserLocation(ctx context.Context, userID string) error {
	key := userLocationKeyPrefix + userID
	if err := s.redisClient.Del(ctx, key).Err(); err != nil {
		s.logger.Error("Failed to unregister user location in Redis", slog.Any("error", err), slog.String("user_id", userID))
		return err
	}
	return nil
}
