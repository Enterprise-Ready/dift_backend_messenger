module dift_backend_go/messaging-service

go 1.25.0

require (
	github.com/go-playground/validator/v10 v10.30.1 // For config validation
	github.com/google/uuid v1.6.0
	github.com/gorilla/websocket v1.5.0
	github.com/nats-io/nats.go v1.31.0
	github.com/redis/go-redis/v9 v9.2.1
	github.com/spf13/viper v1.17.0
	go.mongodb.org/mongo-driver v1.12.1
	golang.org/x/net v0.52.0 // indirect; For websocket
	google.golang.org/protobuf v1.36.11
)

require (
	github.com/cespare/xxhash/v2 v2.3.0 // indirect
	github.com/dgryski/go-rendezvous v0.0.0-20200823014737-9f7001d12a5f // indirect
	github.com/fsnotify/fsnotify v1.6.0 // indirect
	github.com/gabriel-vasile/mimetype v1.4.12 // indirect
	github.com/go-logr/logr v1.4.3 // indirect
	github.com/go-logr/stdr v1.2.2 // indirect
	github.com/go-playground/locales v0.14.1 // indirect
	github.com/go-playground/universal-translator v0.18.1 // indirect
	github.com/go-redis/redis/v8 v8.11.5 // indirect
	github.com/golang/snappy v0.0.1 // indirect
	github.com/hashicorp/hcl v1.0.0 // indirect
	github.com/klauspost/compress v1.17.0 // indirect
	github.com/leodido/go-urn v1.4.0 // indirect
	github.com/magiconair/properties v1.8.7 // indirect
	github.com/mitchellh/mapstructure v1.5.0 // indirect
	github.com/montanaflynn/stats v0.0.0-20171201202039-1bf9dbcd8cbe // indirect
	github.com/nats-io/nkeys v0.4.5 // indirect
	github.com/nats-io/nuid v1.0.1 // indirect
	github.com/pelletier/go-toml/v2 v2.2.4 // indirect
	github.com/sagikazarmark/locafero v0.3.0 // indirect
	github.com/sagikazarmark/slog-shim v0.1.0 // indirect
	github.com/sourcegraph/conc v0.3.0 // indirect
	github.com/spf13/afero v1.10.0 // indirect
	github.com/spf13/cast v1.5.1 // indirect
	github.com/spf13/pflag v1.0.5 // indirect
	github.com/subosito/gotenv v1.6.0 // indirect
	github.com/xdg-go/pbkdf2 v1.0.0 // indirect
	github.com/xdg-go/scram v1.1.2 // indirect
	github.com/xdg-go/stringprep v1.0.4 // indirect
	github.com/youmark/pkcs8 v0.0.0-20181117223130-1be2e3e5546d // indirect
	go.opentelemetry.io/auto/sdk v1.2.1 // indirect
	go.opentelemetry.io/otel v1.43.0 // indirect
	go.opentelemetry.io/otel/metric v1.43.0 // indirect
	go.opentelemetry.io/otel/trace v1.43.0 // indirect
	go.uber.org/atomic v1.9.0 // indirect
	go.uber.org/multierr v1.10.0 // indirect
	go.uber.org/zap v1.28.0 // indirect
	golang.org/x/crypto v0.50.0 // indirect
	golang.org/x/exp v0.0.0-20230905200255-921286631fa9 // indirect
	golang.org/x/sync v0.20.0 // indirect
	golang.org/x/sys v0.43.0 // indirect
	golang.org/x/text v0.36.0 // indirect
	google.golang.org/genproto/googleapis/rpc v0.0.0-20260401024825-9d38bb4040a9 // indirect
	gopkg.in/ini.v1 v1.67.0 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
)

// ... (other indirect dependencies will be added by `go mod tidy`)

require github.com/PlatformCore/middleware v0.0.0

require github.com/PlatformCore/engine-core/runtime v0.0.0

require github.com/PlatformCore/engine-core/messaging v0.0.0

require github.com/PlatformCore/engine-core/observability v0.0.0

require github.com/PlatformCore/engine-core/resilience v0.0.0

replace github.com/PlatformCore/middleware => ../middleware

replace github.com/PlatformCore/engine-core/runtime => ../engine-core/runtime

replace github.com/PlatformCore/engine-core/messaging => ../engine-core/messaging

replace github.com/PlatformCore/engine-core/observability => ../engine-core/observability

replace github.com/PlatformCore/engine-core/resilience => ../engine-core/resilience

require github.com/PlatformCore/engine-core/transport v0.0.0

require github.com/PlatformCore/engine-core/security v0.0.0

require github.com/PlatformCore/engine-core/validation v0.0.0

require github.com/PlatformCore/engine-core/tenant v0.0.0

require (
	github.com/PlatformCore/engine-core/plugins v0.0.0
	google.golang.org/grpc v1.80.0
)

replace github.com/PlatformCore/engine-core/transport => ../engine-core/transport

replace github.com/PlatformCore/engine-core/security => ../engine-core/security

replace github.com/PlatformCore/engine-core/validation => ../engine-core/validation

replace github.com/PlatformCore/engine-core/tenant => ../engine-core/tenant

replace github.com/PlatformCore/engine-core/plugins => ../engine-core/plugins
