package servicecore

// CapabilityProfile documents enterprise package targets for this service.
type CapabilityProfile struct {
	ServiceName         string
	InboundHTTP         bool
	InboundGRPC         bool
	InboundEvent        bool
	OutboundGRPCClient  bool
	OutboundEvent       bool
	HasDBOrMigration    bool
	RecommendedPackages []string
}

func EnterpriseCapabilityProfile() CapabilityProfile {
	return CapabilityProfile{
		ServiceName:         "massenger-service",
		InboundHTTP:         false,
		InboundGRPC:         false,
		InboundEvent:        false,
		OutboundGRPCClient:  false,
		OutboundEvent:       false,
		HasDBOrMigration:    false,
		RecommendedPackages: []string{"engine-core/runtime/app", "middleware/metrics", "middleware/recovery", "middleware/requestid", "middleware/retry", "middleware/timeout", "middleware/validation"},
	}
}
