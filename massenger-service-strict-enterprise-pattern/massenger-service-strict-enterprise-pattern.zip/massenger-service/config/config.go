package config

import (
	"log"
	"strings"

	"github.com/go-playground/validator/v10"
	"github.com/spf13/viper"
)

type Config struct {
	Server   ServerConfig `mapstructure:"server"`
	NATS     NATSConfig   `mapstructure:"nats"`
	Mongo    MongoConfig  `mapstructure:"mongo"`
	Redis    RedisConfig  `mapstructure:"redis"`
	LogLevel string       `mapstructure:"log_level"`
}

type ServerConfig struct {
	WebSocketPort int `mapstructure:"websocket_port" validate:"required,gt=0"`
}

type NATSConfig struct {
	URL            string `mapstructure:"url" validate:"required"`
	DeliveryPrefix string `mapstructure:"delivery_prefix" validate:"required"` // e.g., "messages.delivery"
}

type MongoConfig struct {
	URI        string `mapstructure:"uri" validate:"required"`
	Database   string `mapstructure:"database" validate:"required"`
	Collection string `mapstructure:"collection" validate:"required"`
}

type RedisConfig struct {
	URL      string `mapstructure:"url" validate:"required"`
	Password string `mapstructure:"password"` // Empty if no password
	DB       int    `mapstructure:"db"`
}

func LoadConfig(path string) (*Config, error) {
	viper.AddConfigPath(path)
	viper.SetConfigName("config")
	viper.SetConfigType("yaml")
	viper.AutomaticEnv()
	viper.SetEnvKeyReplacer(strings.NewReplacer(".", "_"))

	// Defaults must be set before unmarshal.
	viper.SetDefault("server.websocket_port", 8080)
	viper.SetDefault("nats.url", "nats://localhost:4222")
	viper.SetDefault("nats.delivery_prefix", "messages.delivery")
	viper.SetDefault("mongo.uri", "mongodb://localhost:27017")
	viper.SetDefault("mongo.database", "messaging")
	viper.SetDefault("mongo.collection", "messages")
	viper.SetDefault("redis.url", "localhost:6379")
	viper.SetDefault("redis.db", 0)
	viper.SetDefault("log_level", "info")

	if err := viper.ReadInConfig(); err != nil {
		log.Printf("Warning: Could not read config file: %v. Using defaults or env vars.", err)
	}

	var cfg Config
	if err := viper.Unmarshal(&cfg); err != nil {
		return nil, err
	}

	// Validate config
	validate := validator.New()
	if err := validate.Struct(&cfg); err != nil {
		return nil, err
	}

	return &cfg, nil
}
