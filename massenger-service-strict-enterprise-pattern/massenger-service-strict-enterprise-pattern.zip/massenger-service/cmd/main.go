package main

import (
	"context"
	"log"
	"os/signal"
	"syscall"

	"dift_backend_go/messaging-service/internal/app"
)

func main() {
	ctx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()

	a, err := app.Bootstrap(ctx)
	if err != nil {
		log.Fatal(err)
	}
	if err := a.Start(ctx); err != nil {
		log.Fatal(err)
	}
	<-ctx.Done()
	_ = a.Stop(context.Background())
}
