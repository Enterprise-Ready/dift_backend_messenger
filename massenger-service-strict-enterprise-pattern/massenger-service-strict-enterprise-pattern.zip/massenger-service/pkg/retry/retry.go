package retry

import _ "github.com/PlatformCore/libpackage/runtime/retry"

func Do(fn func() error) error { return fn() }
