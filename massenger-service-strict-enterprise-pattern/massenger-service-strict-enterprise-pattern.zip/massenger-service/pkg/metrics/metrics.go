package metrics

import (
	_ "github.com/PlatformCore/libpackage/observability/metrics"
	"sync/atomic"
)

type BusinessMetrics struct {
	processed atomic.Int64
	failed    atomic.Int64
}

func NewBusinessMetrics() *BusinessMetrics { return &BusinessMetrics{} }
func (m *BusinessMetrics) RecordProcessed() {
	if m != nil {
		m.processed.Add(1)
	}
}
func (m *BusinessMetrics) RecordFailed() {
	if m != nil {
		m.failed.Add(1)
	}
}
func (m *BusinessMetrics) Snapshot() map[string]int64 {
	if m == nil {
		return map[string]int64{}
	}
	return map[string]int64{"processed_total": m.processed.Load(), "failed_total": m.failed.Load()}
}
