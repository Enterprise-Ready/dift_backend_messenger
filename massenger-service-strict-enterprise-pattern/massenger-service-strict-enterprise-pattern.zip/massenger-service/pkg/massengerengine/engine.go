package massengerengine

import (
	"context"
	_ "github.com/PlatformCore/libpackage/messaging/idempotency"
	_ "github.com/PlatformCore/libpackage/persistence/tx"
)

type Engine struct{}

func New() *Engine                                                        { return &Engine{} }
func (e *Engine) Normalize(ctx context.Context, payload any) (any, error) { return payload, nil }
