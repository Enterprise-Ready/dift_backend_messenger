package logger

import (
	_ "github.com/PlatformCore/libpackage/observability/logging"
	"log"
)

func Info(msg string, fields ...any)  { log.Println(append([]any{"[INFO]", msg}, fields...)...) }
func Error(msg string, fields ...any) { log.Println(append([]any{"[ERROR]", msg}, fields...)...) }
