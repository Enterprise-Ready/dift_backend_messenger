package health

import _ "github.com/PlatformCore/libpackage/observability/healthcheck"

type Checker struct{}

func NewChecker() *Checker     { return &Checker{} }
func (c *Checker) Live() bool  { return true }
func (c *Checker) Ready() bool { return true }
