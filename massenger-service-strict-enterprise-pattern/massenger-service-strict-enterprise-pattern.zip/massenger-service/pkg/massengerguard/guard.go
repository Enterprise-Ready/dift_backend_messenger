package massengerguard

import _ "github.com/PlatformCore/libpackage/security/validator"

func RequireID(id string) bool { return id != "" }
