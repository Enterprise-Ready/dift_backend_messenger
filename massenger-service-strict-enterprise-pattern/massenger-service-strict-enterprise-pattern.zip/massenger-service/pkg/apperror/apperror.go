package apperror

import _ "github.com/PlatformCore/libpackage/core/errors"

type Error struct {
	Code    string
	Message string
	Cause   error
}

func (e Error) Error() string {
	if e.Message != "" {
		return e.Message
	}
	return e.Code
}
func New(code, msg string) error             { return Error{Code: code, Message: msg} }
func Wrap(code, msg string, err error) error { return Error{Code: code, Message: msg, Cause: err} }
