package db

import (
	"context"
	"dift_backend_go/messaging-service/internal/pb"
	"log/slog"
	"time"

	"go.mongodb.org/mongo-driver/bson"
	"go.mongodb.org/mongo-driver/bson/primitive"
	"go.mongodb.org/mongo-driver/mongo"
	"go.mongodb.org/mongo-driver/mongo/options"
	"google.golang.org/protobuf/types/known/timestamppb"
)

// MongoRepository implements the MessengerRepository interface using MongoDB.
type MongoRepository struct {
	client     *mongo.Client
	collection *mongo.Collection
	logger     *slog.Logger
}

// NewMongoRepository creates a new MongoDB repository.
func NewMongoRepository(ctx context.Context, client *mongo.Client, dbName, collectionName string, logger *slog.Logger) (*MongoRepository, error) {
	collection := client.Database(dbName).Collection(collectionName)

	// Create index on conversation_id and timestamp for efficient history queries
	indexModel := mongo.IndexModel{
		Keys:    bson.D{{Key: "conversation_id", Value: 1}, {Key: "timestamp", Value: -1}},
		Options: options.Index(),
	}
	_, err := collection.Indexes().CreateOne(ctx, indexModel)
	if err != nil {
		logger.Error("Failed to create index in MongoDB", slog.Any("error", err))
		return nil, err
	}

	return &MongoRepository{
		client:     client,
		collection: collection,
		logger:     logger,
	}, nil
}

// SaveMessage saves a pb.Message to MongoDB.
func (r *MongoRepository) SaveMessage(ctx context.Context, msg *pb.Message) error {
	// We convert to a BSON document for storage, especially for the timestamp.
	doc := bson.M{
		"_id":             msg.Id,
		"conversation_id": msg.ConversationId,
		"from":            msg.From,
		"to":              msg.To,
		"content":         msg.Content,
		"timestamp":       msg.Timestamp.AsTime(), // Store as BSON Date
	}

	_, err := r.collection.InsertOne(ctx, doc)
	if err != nil {
		r.logger.Error("Failed to insert message into MongoDB", slog.Any("error", err))
		return err
	}
	return nil
}

// GetMessages retrieves messages from MongoDB, newest first.
func (r *MongoRepository) GetMessages(ctx context.Context, conversationID string, limit int) ([]*pb.Message, error) {
	opts := options.Find().
		SetSort(bson.D{{Key: "timestamp", Value: -1}}).
		SetLimit(int64(limit))

	filter := bson.M{"conversation_id": conversationID}

	cursor, err := r.collection.Find(ctx, filter, opts)
	if err != nil {
		r.logger.Error("Failed to find messages in MongoDB", slog.Any("error", err))
		return nil, err
	}
	defer cursor.Close(ctx)

	var messages []*pb.Message
	for cursor.Next(ctx) {
		var doc bson.M
		if err := cursor.Decode(&doc); err != nil {
			r.logger.Warn("Failed to decode message from MongoDB", slog.Any("error", err))
			continue
		}

		msgID, _ := doc["_id"].(string)
		conversationID, _ := doc["conversation_id"].(string)
		from, _ := doc["from"].(string)
		to, _ := doc["to"].(string)
		content, _ := doc["content"].(string)
		ts := parseBSONTime(doc["timestamp"])

		// Convert BSON doc back to pb.Message
		msg := &pb.Message{
			Id:             msgID,
			ConversationId: conversationID,
			From:           from,
			To:             to,
			Content:        content,
			Timestamp:      timestamppb.New(ts),
		}
		messages = append(messages, msg)
	}

	// Reverse the slice because we retrieved newest-first, but want to send oldest-first
	// so they appear in chronological order on the client.
	for i, j := 0, len(messages)-1; i < j; i, j = i+1, j-1 {
		messages[i], messages[j] = messages[j], messages[i]
	}

	return messages, nil
}

func parseBSONTime(v interface{}) time.Time {
	switch t := v.(type) {
	case primitive.DateTime:
		return t.Time()
	case time.Time:
		return t
	default:
		return time.Now().UTC()
	}
}
