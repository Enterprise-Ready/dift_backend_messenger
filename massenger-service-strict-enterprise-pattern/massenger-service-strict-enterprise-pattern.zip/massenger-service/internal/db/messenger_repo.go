package db

import (
	"context"
	"dift_backend_go/messaging-service/internal/pb"
)

// MessengerRepository defines the interface for message persistence.
type MessengerRepository interface {
	SaveMessage(ctx context.Context, msg *pb.Message) error
	// GetMessages retrieves messages for a specific conversation, sorted newest first.
	GetMessages(ctx context.Context, conversationID string, limit int) ([]*pb.Message, error)
}
