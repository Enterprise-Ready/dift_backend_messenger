package app

type Services struct{}

func wireServices(adapters *Adapters) *Services { return &Services{} }
