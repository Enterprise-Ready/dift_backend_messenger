package app

import "context"

type Infra struct{}

func wireIntegration(ctx context.Context) (*Infra, error) { return &Infra{}, nil }
