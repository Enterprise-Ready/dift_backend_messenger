package app

import "context"

type App struct{}

func Bootstrap(ctx context.Context) (*App, error) { return &App{}, nil }
func (a *App) Start(ctx context.Context) error    { return nil }
func (a *App) Stop(ctx context.Context) error     { return nil }
