package app

type Adapters struct{}

func wireAdapters(infra *Infra) *Adapters { return &Adapters{} }
