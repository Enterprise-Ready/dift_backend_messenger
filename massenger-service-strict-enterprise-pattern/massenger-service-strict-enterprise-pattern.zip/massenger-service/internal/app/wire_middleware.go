package app

import "net/http"

func wireHTTPMiddleware(next http.Handler) http.Handler { return next }
