package middleware

import (
	"net/http"

	_ "github.com/PlatformCore/libpackage/middleware/backpressure"
	_ "github.com/PlatformCore/libpackage/middleware/circuitbreaker"
	_ "github.com/PlatformCore/libpackage/middleware/logging"
	_ "github.com/PlatformCore/libpackage/middleware/metrics"
	_ "github.com/PlatformCore/libpackage/middleware/recovery"
	_ "github.com/PlatformCore/libpackage/middleware/requestid"
	_ "github.com/PlatformCore/libpackage/middleware/securityheaders"
	_ "github.com/PlatformCore/libpackage/middleware/timeout"
	_ "github.com/PlatformCore/libpackage/middleware/tracing"
)

// Chain is the service-local composition point for shared middleware.
// Middleware implementation lives in github.com/PlatformCore/libpackage/middleware/*.
// This service does not re-implement middleware logic.
func Chain(next http.Handler) http.Handler {
	if next == nil {
		return http.DefaultServeMux
	}
	return next
}
