package handler

import (
	"context"
	"fmt"
	"log/slog"
	"net/http"
	"sync"
	"time"

	"dift_backend_go/messaging-service/internal/pb"
	"dift_backend_go/messaging-service/internal/service"

	"github.com/gorilla/websocket"
	"github.com/nats-io/nats.go"
	"google.golang.org/protobuf/encoding/protojson"
	"google.golang.org/protobuf/proto"
)

const (
	writeWait      = 10 * time.Second    // Time allowed to write a message to the peer.
	pongWait       = 60 * time.Second    // Time allowed to read the next pong message from the peer.
	pingPeriod     = (pongWait * 9) / 10 // Send pings to peer with this period. Must be less than pongWait.
	maxMessageSize = 1024 * 4            // Maximum message size allowed from peer (4KB)
	historyLimit   = 50                  // Number of past messages to fetch on connect
)

var upgrader = websocket.Upgrader{
	ReadBufferSize:  1024,
	WriteBufferSize: 1024,
	CheckOrigin: func(r *http.Request) bool {
		// Allow all origins for simplicity.
		// TODO: Restrict this in production.
		return true
	},
}

// Client is a middleman between the websocket connection and the hub.
type Client struct {
	hub            *Hub
	conn           *websocket.Conn
	send           chan *pb.Message // Buffered channel of outbound messages.
	userID         string
	conversationID string
}

// Hub manages all active clients and broadcasts messages.
type Hub struct {
	clients    map[string]*Client // Map of userID -> Client
	mu         sync.RWMutex       // Protects the clients map
	register   chan *Client       // Register requests from clients.
	unregister chan *Client       // Unregister requests from clients.
	service    *service.MessagingService
	natsConn   *nats.Conn
	serviceID  string // Unique ID for this service instance
	logger     *slog.Logger
}

func NewHub(logger *slog.Logger, svc *service.MessagingService, nc *nats.Conn, serviceID, deliveryPrefix string) *Hub {
	hub := &Hub{
		clients:    make(map[string]*Client),
		register:   make(chan *Client),
		unregister: make(chan *Client),
		service:    svc,
		natsConn:   nc,
		serviceID:  serviceID,
		logger:     logger,
	}

	// Start the NATS subscriber for this service instance
	deliveryTopic := fmt.Sprintf("%s.%s", deliveryPrefix, serviceID)
	_, err := nc.Subscribe(deliveryTopic, hub.handleNatsDelivery)
	if err != nil {
		logger.Error("Failed to subscribe to NATS delivery topic", slog.Any("error", err), slog.String("topic", deliveryTopic))
		panic(err) // Critical failure
	}
	logger.Info("Subscribed to NATS delivery topic", slog.String("topic", deliveryTopic))

	// Start the hub's run loop
	go hub.run()
	return hub
}

// run is the main event loop for the hub.
func (h *Hub) run() {
	for {
		select {
		case client := <-h.register:
			h.mu.Lock()
			h.clients[client.userID] = client
			h.mu.Unlock()
			h.logger.Info("Client registered", slog.String("user_id", client.userID))
		case client := <-h.unregister:
			h.mu.Lock()
			if _, ok := h.clients[client.userID]; ok {
				delete(h.clients, client.userID)
				close(client.send)
			}
			h.mu.Unlock()
			h.logger.Info("Client unregistered", slog.String("user_id", client.userID))
		}
	}
}

// handleNatsDelivery is called when a NATS message arrives on this service's specific topic.
func (h *Hub) handleNatsDelivery(msg *nats.Msg) {
	var m pb.Message
	if err := proto.Unmarshal(msg.Data, &m); err != nil {
		h.logger.Error("Failed to unmarshal NATS message", slog.Any("error", err))
		return
	}

	h.logger.Info("Received NATS message for delivery", slog.String("to", m.To), slog.String("conv_id", m.ConversationId))

	h.mu.RLock()
	client, ok := h.clients[m.To]
	h.mu.RUnlock()

	if !ok {
		h.logger.Warn("Client not found for NATS delivery", slog.String("user_id", m.To))
		return
	}

	// Check if the client is in the correct conversation
	if client.conversationID != m.ConversationId {
		h.logger.Warn("Client is in a different conversation, not delivering.",
			slog.String("user_id", client.userID),
			slog.String("client_conv", client.conversationID),
			slog.String("msg_conv", m.ConversationId))
		return
	}

	// Send to the client's send channel
	select {
	case client.send <- &m:
	default:
		// Send channel is full, client might be slow or stuck
		h.logger.Warn("Client send channel full, dropping message.", slog.String("user_id", client.userID))
		// Optionally, disconnect the client
		// client.conn.Close()
	}
}

// ServeWS handles websocket requests from the peer.
func (h *Hub) ServeWS(w http.ResponseWriter, r *http.Request) {
	// 1. Get query params
	userID := r.URL.Query().Get("user_id")
	conversationID := r.URL.Query().Get("conversation_id")
	if userID == "" || conversationID == "" {
		h.logger.Error("Missing user_id or conversation_id query param")
		http.Error(w, "user_id and conversation_id are required", http.StatusBadRequest)
		return
	}

	// 2. Upgrade connection
	conn, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		h.logger.Error("WebSocket upgrade failed", slog.Any("error", err))
		return
	}
	h.logger.Info("WebSocket connection upgraded", slog.String("user_id", userID), slog.String("conv_id", conversationID))

	// 3. Create and register the client
	client := &Client{
		hub:            h,
		conn:           conn,
		send:           make(chan *pb.Message, 256), // Buffered channel
		userID:         userID,
		conversationID: conversationID,
	}
	h.register <- client

	// 4. Register location in Redis
	// We do this in a goroutine to not block the connection
	go func() {
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		if err := h.service.RegisterUserLocation(ctx, client.userID, h.serviceID); err != nil {
			h.logger.Error("Failed to register user location in ServeWS", slog.Any("error", err))
		}
	}()

	// 5. Start goroutines for reading and writing
	go client.writePump()
	go client.readPump()

	// 6. Send chat history
	go func() {
		ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		history, err := h.service.GetMessageHistory(ctx, client.conversationID, historyLimit)
		if err != nil {
			h.logger.Error("Failed to get message history", slog.Any("error", err), slog.String("conv_id", client.conversationID))
			return
		}

		h.logger.Info("Sending message history", slog.Int("count", len(history)), slog.String("user_id", client.userID))
		for _, msg := range history {
			client.send <- msg
		}
	}()
}

// readPump pumps messages from the websocket connection to the hub.
func (c *Client) readPump() {
	defer func() {
		// Cleanup: unregister client and close connection
		c.hub.unregister <- c
		c.conn.Close()

		// Unregister from Redis
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		if err := c.hub.service.UnregisterUserLocation(ctx, c.userID); err != nil {
			c.hub.logger.Error("Failed to unregister user location in readPump", slog.Any("error", err))
		}
		c.hub.logger.Info("readPump closed", slog.String("user_id", c.userID))
	}()

	c.conn.SetReadLimit(maxMessageSize)
	c.conn.SetReadDeadline(time.Now().Add(pongWait))
	c.conn.SetPongHandler(func(string) error { c.conn.SetReadDeadline(time.Now().Add(pongWait)); return nil })

	for {
		// ReadJSON is not ideal for protobuf, but it's simple.
		// A binary format (ReadMessage) would be more efficient.
		// For this example, we'll assume client sends JSON representation of pb.Message.
		var msg pb.Message
		err := c.conn.ReadJSON(&msg) // Note: This is a custom struct, not pb.Message
		if err != nil {
			if websocket.IsUnexpectedCloseError(err, websocket.CloseGoingAway, websocket.CloseAbnormalClosure) {
				c.hub.logger.Error("Unexpected WebSocket close error", slog.Any("error", err))
			} else {
				c.hub.logger.Info("WebSocket closed", slog.Any("error", err))
			}
			break
		}

		// 1. Enrich the message from the client
		msg.From = c.userID
		msg.ConversationId = c.conversationID
		// 'To' and 'Content' should be set by the client.

		if msg.To == "" || msg.Content == "" {
			c.hub.logger.Warn("Received incomplete message from client", slog.String("user_id", c.userID))
			continue
		}

		// 2. Send to the messaging service for persistence and routing
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		if err := c.hub.service.SendMessage(ctx, &msg); err != nil {
			c.hub.logger.Error("Failed to send message from readPump", slog.Any("error", err))
			// Optionally, send an error message back to the client
		}
		cancel()
	}
}

// writePump pumps messages from the hub to the websocket connection.
func (c *Client) writePump() {
	ticker := time.NewTicker(pingPeriod)
	defer func() {
		// Cleanup: stop ticker, unregister, close connection
		ticker.Stop()
		c.conn.Close()
		c.hub.logger.Info("writePump closed", slog.String("user_id", c.userID))
	}()

	for {
		select {
		case message, ok := <-c.send:
			c.conn.SetWriteDeadline(time.Now().Add(writeWait))
			if !ok {
				// The hub closed the channel.
				c.conn.WriteMessage(websocket.CloseMessage, []byte{})
				return
			}

			// Use protojson to send standard JSON over WebSocket
			// This is easier for web/mobile clients to consume.
			m := protojson.MarshalOptions{
				EmitUnpopulated: true,
				UseProtoNames:   true,
			}
			jsonBytes, err := m.Marshal(message)
			if err != nil {
				c.hub.logger.Error("Failed to marshal message to JSON", slog.Any("error", err))
				continue
			}

			if err := c.conn.WriteMessage(websocket.TextMessage, jsonBytes); err != nil {
				c.hub.logger.Error("WebSocket write error", slog.Any("error", err))
				return
			}

		case <-ticker.C:
			// Send ping
			c.conn.SetWriteDeadline(time.Now().Add(writeWait))
			if err := c.conn.WriteMessage(websocket.PingMessage, nil); err != nil {
				c.hub.logger.Error("WebSocket ping error", slog.Any("error", err))
				return
			}
		}
	}
}
