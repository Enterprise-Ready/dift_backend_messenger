# massenger-service strict enterprise pattern

This service was normalized to the same pattern as the latest travel/reward reference.

## Rules

- `cmd/main.go`: entrypoint only.
- `internal/app`: bootstrap and wiring only.
- `internal/integration`: infra/client/server only.
- `internal/adapter/inbound`: HTTP/gRPC/event consumers.
- `internal/adapter/outbound`: repositories/producers/cache/RPC clients.
- `internal/service_logic`: business flow stays here when present.
- `pkg`: service-specific wrappers around direct engine packages only.
- Middleware is imported directly from `github.com/PlatformCore/libpackage/middleware/*` in inbound middleware composition.
- Engine-core packages are imported only from service-local `pkg/*` wrappers.
- Legacy/uncertain code is preserved under `docs/legacy-*` to avoid logic loss.
